const text = document.getElementById("text");
const results = document.getElementById("results");
const words = document.getElementById("words");
const form = document.getElementById("form");

let currentData = {};
let currentQuery = "";

docReady(createForm);

function createForm() {
  Api.getAllWords().then((data) => {
    for (let word of data.words) {
      console.log(word);
      const input = document.createElement("input");
      input.setAttribute("type", "checkbox");
      input.setAttribute("id", word.id);
      input.setAttribute("name", word.lemma);
      input.setAttribute("value", word.id);

      const label = createElementFromText("label", word.lemma);
      label.setAttribute("for", word.lemma);

      const div = document.createElement("div");
      div.appendChild(input);
      div.appendChild(label);
      div.appendChild(document.createElement("br"));

      document.getElementById("queries").appendChild(div);
    }
    form.addEventListener("submit", submit);
  });
}

function showData() {
  clearData();
  showText();
  showWords();
  showResults();
}

function showText() {
  //Pour chaque titre
  currentData.data.text.content.forEach((division) => {
    //titleText = lookupQuery(currentQuery, titleText) || titleText;
    division.text =
      lookupQueries(currentData.data.queries, division.text) || division.text;

    text.appendChild(createElementFromText("h3", division.name));
    text.appendChild(createElementFromText("p", division.text));
  });
}

function showWords() {
  //Pour chaque mot
  for (let result in currentData.data.totalFrequency) {
    const text = result + " : " + currentData.data.totalFrequency[result];
    words.appendChild(createElementFromText("p", text));
  }
}

function showResults() {
  const text = "Ratio total : " + currentData.data.totalRatio;
  results.appendChild(createElementFromText("h4", text));
}

function clearData() {
  while (results.lastElementChild) {
    results.removeChild(results.lastElementChild);
  }

  while (words.lastElementChild) {
    words.removeChild(words.lastElementChild);
  }

  while (text.lastElementChild) {
    text.removeChild(text.lastElementChild);
  }
}

function lookupQueries(queries, text) {
  for (query of queries) {
    query.regex = new RegExp(query.root, "gi");
    text = text.replace(query.regex, (match) => `<mark>${match}</mark>`);
  }
  return text;
}

function submit(form) {
  const reqBody = {
    url: "../" + document.getElementById("url").value,
    queries: getCurrentQueries(),
    precision: 25, //Pour le moment
  };

  Api.getAlgoResult(reqBody).then((data) => {
    currentData = data;
    showData();
  });
}

function getCurrentQueries() {
  const results = [];
  markedCheckbox = document.querySelectorAll('input[type="checkbox"]:checked');
  for (let checkbox of markedCheckbox) {
    results.push(checkbox.value);
  }
  return results;
}
